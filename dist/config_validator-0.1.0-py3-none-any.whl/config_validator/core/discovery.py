from __future__ import annotations

from pathlib import Path
from typing import Iterable

from ..storage.base_strategy import StorageStrategy
from ..utils.log_decorator import log_process


class Discovery:
    """File discovery service using storage strategy."""

    def __init__(self, root: Path, storage_strategy: StorageStrategy) -> None:
        """Initialize discovery with root path and storage strategy."""
        self.root = root
        self._storage_strategy = storage_strategy

    @log_process()
    def discover_yaml_files(self, root: Path) -> Iterable[Path]:
        return self._storage_strategy.get_yaml_files(root)
 