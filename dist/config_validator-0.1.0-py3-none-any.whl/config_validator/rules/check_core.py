from __future__ import annotations

import logging
from typing import Any, List

from ..core.types import ValidationIssue
from ..utils.decorators import (
    run_checks,
    require_fields,
    replicas_in_range,
    image_matches,
    env_key_case,
    service_name_not_empty,
)

logger = logging.getLogger(__name__)


@run_checks
@require_fields(lambda cfg: cfg.required_fields)
@replicas_in_range(lambda cfg: (cfg.replicas_min, cfg.replicas_max))
@image_matches(lambda cfg: cfg.image_pattern)
@env_key_case(lambda cfg: cfg.env_key_case)
@service_name_not_empty 
def validate_core(data: dict, config: Any) -> List[ValidationIssue]:
    """Core validation with multiple checks applied via decorators."""
    logger.debug("Core validation invoked. Data type: %s", type(data))
    return []
