from __future__ import annotations

import logging
from typing import Any, List

from ..core.types import ValidationIssue
from ..utils.decorators import run_checks, database_not_forbidden_name

logger = logging.getLogger(__name__)


@run_checks
@database_not_forbidden_name(lambda cfg: getattr(cfg, 'forbidden_database_name', 'test'))
def validate_database(data: dict, config: Any) -> List[ValidationIssue]:
    """Validate that database name is not forbidden."""
    return []