from __future__ import annotations

import logging
from typing import Any, List

from ..core.types import ValidationIssue
from ..utils.decorators import run_checks, env_value_not_empty

logger = logging.getLogger(__name__)


@run_checks
@env_value_not_empty
def validate_env(data: dict, config: Any) -> List[ValidationIssue]:
    """Ensure all env values are non-empty strings."""
    return []