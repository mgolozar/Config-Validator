from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Iterable


class StorageStrategy(ABC):
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
    
    @abstractmethod
    def validate_config(self) -> bool:
        pass

    @staticmethod
    @abstractmethod
    def get_yaml_files(root: Path) -> Iterable[Path]:
        pass

    @abstractmethod
    def read_file(self, remote_path: str) -> str:
        pass
