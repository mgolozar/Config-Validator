from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List

from ..storage.base_strategy import StorageStrategy
from .config import ValidationConfig
from .rules_loader import load_rules
from .types import ValidationIssue

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of validating a single file."""
    path: str
    valid: bool
    errors: List[str]
    issues: List[Dict[str, Any]]
    registry: str | None
    data: Dict[str, Any] | None


class BaseValidator(ABC):
    """Abstract base class for all validators."""
    
    def __init__(self, config: ValidationConfig, storage: StorageStrategy) -> None:
        """Initialize validator with config and storage strategy."""
        self.config = config
        self.storage = storage
        self._validators: List[Callable] | None = None
    
    @property
    def validators(self) -> List[Callable]:
        """Lazy load validator functions when first accessed."""
        if self._validators is None:
            self._validators = load_rules()
        return self._validators
    
    def _read_and_parse_file(self, file_path: str) -> tuple[Dict[str, Any] | None, List[str]]:
        """Read and parse a YAML file, returning data and any errors."""
        errors: List[str] = []
        
        try:
            # Read file content
            content = self.storage.read_file(file_path)
            logger.debug(f"Successfully read file: {file_path}")
        except Exception as e:
            error_msg = f"Failed to read file {file_path}: {e}"
            logger.error(error_msg, exc_info=True)
            return None, [error_msg]
        
        try:
            # Parse YAML
            import yaml
            data = yaml.safe_load(content) or {}
            logger.debug(f"Successfully parsed YAML from file: {file_path}")
        except yaml.YAMLError as e:
            error_msg = f"YAML parse error in {file_path}: {e}"
            logger.error(error_msg, exc_info=True)
            return None, [error_msg]
        except Exception as e:
            error_msg = f"Error parsing YAML from {file_path}: {e}"
            logger.error(error_msg, exc_info=True)
            return None, [error_msg]
        
        # Handle list data structures
        try:
            if isinstance(data, list):
                logger.debug(f"File contains list data, converting to dict")
                d = {}
                for x in data:
                    if isinstance(x, dict):
                        d.update(x)
                data = d
                logger.debug(f"Successfully converted list to dict")
        except Exception as e:
            error_msg = f"Error processing list data from {file_path}: {e}"
            logger.error(error_msg, exc_info=True)
            errors.append(error_msg)
        
        return data, errors
    
    def _extract_registry(self, data: Dict[str, Any]) -> str | None:
        """Extract registry from image field in data."""
        try:
            img = data.get("image")
            if isinstance(img, str):
                import re
                image_re = re.compile(self.config.image_pattern)
                m = image_re.match(img)
                if m:
                    registry = m.group("registry")
                    logger.debug(f"Extracted registry: {registry}")
                    return registry
        except Exception as e:
            error_msg = f"Error extracting registry: {e}"
            logger.warning(error_msg, exc_info=True)
            
        return None
    
    def _build_search_keys(self, issue: ValidationIssue, data: Dict[str, Any] | None, registry: str | None) -> None:
        """Build search keys for an issue based on its metadata and context."""
        keys = [f"rule:{issue.rule_id}"]
        
        # Add keyword-based keys
        for k in issue.keywords:
            keys.append(f"keyword:{k}")
        
        # Add service-based key
        if data and isinstance(data, dict):
            svc = data.get("service")
            if svc:
                keys.append(f"service:{svc}")
        
        # Add registry-based key
        if registry:
            keys.append(f"registry:{registry}")
        
        # Sort and deduplicate
        issue.search_keys = sorted(set(keys))
    
    def _run_validation_rules(self, data: Dict[str, Any], file_path: str) -> List[ValidationIssue]:
        """Run all validator functions with data and config."""
        issues: List[ValidationIssue] = []
        
        try:
            for validator_func in self.validators:
                try:
                    # Call the validator function with data and config
                    rule_issues = validator_func(data, self.config)
                    if rule_issues:
                        logger.debug(f"Validator {validator_func.__qualname__} found {len(rule_issues)} issue(s)")
                        issues.extend(rule_issues)
                except Exception as rule_exc:
                    error_msg = f"Validator {validator_func.__qualname__} error: {rule_exc}"
                    logger.exception(error_msg)
                    issues.append(ValidationIssue(
                        rule_id=f"{validator_func.__qualname__}.error",
                        message=error_msg,
                        keywords=["error"]
                    ))
        except Exception as e:
            error_msg = f"Error loading or running validators for {file_path}: {e}"
            logger.error(error_msg, exc_info=True)
            issues.append(ValidationIssue(
                rule_id="validators.load_error",
                message=error_msg,
                keywords=["error"]
            ))
        
        return issues
    
    @abstractmethod
    def validate_file(self, file_path: str) -> ValidationResult:
        """Validate a single file and return the result."""
        pass
    
    @abstractmethod
    def validate_files(self, file_paths: List[str]) -> List[ValidationResult]:
        pass
