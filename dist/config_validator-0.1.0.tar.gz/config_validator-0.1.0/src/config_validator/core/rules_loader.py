from __future__ import annotations
import importlib
import pkgutil
from typing import Callable, List

_DEF_PKG = "config_validator.rules"

# A validator function signature: (data: dict, config: Any) -> List[ValidationIssue]
ValidatorFn = Callable[..., list]


def load_rules(config=None) -> List[ValidatorFn]:
    """
    Load all validator functions from the rules package.
    A function is considered a validator if it has __is_validator__ = True (set by @run_checks).
    """
    validators: List[ValidatorFn] = []
    pkg = importlib.import_module(_DEF_PKG)
    
    for m in pkgutil.iter_modules(pkg.__path__, prefix=f"{_DEF_PKG}."):
        try:
            module = importlib.import_module(m.name)
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                # Check if it's a callable with the __is_validator__ marker
                if callable(attr) and getattr(attr, "__is_validator__", False):
                    validators.append(attr)
        except Exception as e:
            # Skip modules that can't be imported
            continue
    
    return validators