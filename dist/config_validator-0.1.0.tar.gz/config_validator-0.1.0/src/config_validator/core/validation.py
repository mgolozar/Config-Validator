from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, List
import logging

from .types import ValidationIssue


@dataclass
class ValidationContext:
    """Context for validation execution with shared state."""
    data: dict
    config: Any
    logger: logging.Logger
    issues: List[ValidationIssue] = field(default_factory=list)

    def add(self, issue: ValidationIssue) -> None:
        """Add a validation issue to the context."""
        self.issues.append(issue)
