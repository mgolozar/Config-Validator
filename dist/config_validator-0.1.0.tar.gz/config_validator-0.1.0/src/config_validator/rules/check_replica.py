from __future__ import annotations

import logging
from typing import Any, List

from ..core.types import ValidationIssue
from ..utils.decorators import run_checks, replicas_in_range

logger = logging.getLogger(__name__)


@run_checks
@replicas_in_range(lambda cfg: (1, 10))
def validate_replica(data: dict, config: Any) -> List[ValidationIssue]:
    """Ensure all replica values are between 1 and 10."""
    return []