"""Storage backend strategy pattern implementation."""

from .base_strategy import StorageStrategy
from .local_strategy import LocalStrategy
from .strategy_loader import load_storage_strategy

__all__ = [
    "StorageStrategy",
    "LocalStrategy",
    "load_storage_strategy",
]
