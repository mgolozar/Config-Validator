from __future__ import annotations
import functools
import inspect
import logging
import re
from typing import Any, Callable, Iterable, List, Tuple

from ..core.validation import ValidationContext
from ..core.types import ValidationIssue

logger = logging.getLogger(__name__)


def _ensure_checks_attr(func):
    """Ensure function has __checks__ attribute."""
    if not hasattr(func, "__checks__"):
        setattr(func, "__checks__", [])
    return func.__checks__


def _register_check(func, check_callable: Callable[[ValidationContext], None]):
    """Register a check callable on a function."""
    checks = _ensure_checks_attr(func)
    checks.append(check_callable)


def run_checks(fn):
    """
    Orchestrator: executes all checks attached via other decorators.
    Must be applied on TOP of the stack so all prior decorators have already registered their checks.
    Marks the function as a validator via __is_validator__ = True.
    """
    setattr(fn, "__is_validator__", True)

    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def wrapper(data: dict, config: Any) -> List[ValidationIssue]:
            ctx = ValidationContext(data=data, config=config, logger=logging.getLogger(fn.__module__))
            # run registered checks in the order they were declared
            for check in getattr(fn, "__checks__", []):
                if inspect.iscoroutinefunction(check):
                    await check(ctx)
                else:
                    check(ctx)
            # original body can add more issues or just return []
            try:
                result = await fn(data, config)
            except Exception:
                ctx.logger.exception("Error in validator body: %s", fn.__qualname__)
                raise
            return ctx.issues + (result or [])
        return wrapper
    else:
        @functools.wraps(fn)
        def wrapper(data: dict, config: Any) -> List[ValidationIssue]:
            ctx = ValidationContext(data=data, config=config, logger=logging.getLogger(fn.__module__))
            for check in getattr(fn, "__checks__", []):
                check(ctx)
            try:
                result = fn(data, config)
            except Exception:
                ctx.logger.exception("Error in validator body: %s", fn.__qualname__)
                raise
            return ctx.issues + (result or [])
        return wrapper


# ---- Generic helper to create checks ---------------------------------

def _make_sync_check(target_fn, check_impl: Callable[[ValidationContext], None]):
    """Helper to register a synchronous check on a target function."""
    _register_check(target_fn, check_impl)
    return target_fn


# ---- Concrete check decorators ---------------------------------------

def require_fields(fields_provider: Callable[[Any], Iterable[str]]):
    """Decorator that requires specified fields to be present in data."""
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                required = set(fields_provider(ctx.config))
                missing = sorted(required - set((ctx.data or {}).keys()))
                if missing:
                    ctx.logger.warning("Missing required keys: %s", missing)
                    ctx.add(ValidationIssue(
                        rule_id="schema.required_keys",
                        message=f"Missing required keys: {missing}",
                        keywords=["schema", "required"]
                    ))
            except Exception as e:
                ctx.logger.error("Error checking required fields: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="schema.required_keys",
                    message=f"Error checking required fields: {e}",
                    keywords=["schema", "required"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


def replicas_in_range(bounds_provider: Callable[[Any], Tuple[int, int]]):
    """Decorator that validates replicas are within specified range."""
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                rep = (ctx.data or {}).get("replicas")
                rmin, rmax = bounds_provider(ctx.config)
                if not isinstance(rep, int) or not (rmin <= rep <= rmax):
                    ctx.logger.warning("replicas must be an integer between %s and %s", rmin, rmax)
                    ctx.add(ValidationIssue(
                        rule_id="replicas.range",
                        message=f"replicas must be an integer between {rmin} and {rmax}",
                        keywords=["replicas", "range"]
                    ))
            except Exception as e:
                ctx.logger.error("Error validating replicas: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="replicas.range",
                    message=f"Error validating replicas: {e}",
                    keywords=["replicas", "range"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


def image_matches(pattern_provider: Callable[[Any], str]):
    """Decorator that validates image matches a specified pattern."""
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                img = (ctx.data or {}).get("image")
                if not isinstance(img, str):
                    ctx.logger.warning("image must be a string like registry/service:version")
                    ctx.add(ValidationIssue(
                        rule_id="image.format",
                        message="image must be a string like registry/service:version",
                        keywords=["image", "format"]
                    ))
                    return
                pattern = pattern_provider(ctx.config)
                if not re.compile(pattern).match(img):
                    ctx.logger.warning("image must match <registry>/<service>:<version>")
                    ctx.add(ValidationIssue(
                        rule_id="image.format",
                        message="image must match <registry>/<service>:<version>",
                        keywords=["image", "format"]
                    ))
            except Exception as e:
                ctx.logger.error("Error validating image: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="image.format",
                    message=f"Error validating image: {e}",
                    keywords=["image", "format"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


def env_key_case(mode_provider: Callable[[Any], str]):
    """Decorator that validates environment variable key case."""
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                env = (ctx.data or {}).get("env", {})
                if env not in (None, {}):
                    if not isinstance(env, dict):
                        ctx.logger.warning("env must be a mapping of key->value")
                        ctx.add(ValidationIssue(
                            rule_id="env.type",
                            message="env must be a mapping of key->value",
                            keywords=["env", "type"]
                        ))
                        return
                    mode = mode_provider(ctx.config)
                    if mode == "UPPERCASE":
                        non_upper = [k for k in env.keys() if not (isinstance(k, str) and k.isupper())]
                        if non_upper:
                            ctx.logger.warning("env keys must be UPPERCASE: %s", non_upper)
                            ctx.add(ValidationIssue(
                                rule_id="env.key_case",
                                message=f"env keys must be UPPERCASE: {sorted(non_upper)}",
                                keywords=["env", "case"]
                            ))
                    elif mode == "lowercase":
                        non_lower = [k for k in env.keys() if not (isinstance(k, str) and k.islower())]
                        if non_lower:
                            ctx.logger.warning("env keys must be lowercase: %s", non_lower)
                            ctx.add(ValidationIssue(
                                rule_id="env.key_case",
                                message=f"env keys must be lowercase: {sorted(non_lower)}",
                                keywords=["env", "case"]
                            ))
            except Exception as e:
                ctx.logger.error("Error validating environment variables: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="env.validation",
                    message=f"Error validating environment variables: {e}",
                    keywords=["env"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


 

def env_value_not_empty(target_fn):
    """Decorator that ensures all env values are non-empty strings."""
    def check(ctx: ValidationContext):
        try:
            env = (ctx.data or {}).get("env")
            if isinstance(env, dict):
                bad = [k for k, v in env.items() if not isinstance(v, str) or v.strip() == ""]
                if bad:
                    ctx.logger.warning("env values must be non-empty strings: %s", bad)
                    ctx.add(ValidationIssue(
                        rule_id="env.value_empty",
                        message=f"env values must be non-empty strings: {sorted(bad)}",
                        keywords=["env", "empty"]
                    ))
        except Exception as e:
            ctx.logger.error("Error validating env values: %s", e, exc_info=True)
            ctx.add(ValidationIssue(
                rule_id="env.value_empty",
                message=f"Error validating env values: {e}",
                keywords=["env", "empty"]
            ))
    return _make_sync_check(target_fn, check)



def service_name_not_empty(target_fn):
    """Decorator that ensures the service name is not empty."""
    def check(ctx: ValidationContext):
        try:
            service_name = (ctx.data or {}).get("service")
            if not isinstance(service_name, str) or service_name.strip() == "":
                ctx.logger.warning("service name must be a non-empty string")
                ctx.add(ValidationIssue(
                    rule_id="service.name_empty",
                    message="service name must be a non-empty string",
                    keywords=["service", "name", "empty"]
                ))
        except Exception as e:
            ctx.logger.error("Error validating service name: %s", e, exc_info=True)
            ctx.add(ValidationIssue(
                rule_id="env.value_empty",
                message=f"Error validating env values: {e}",
                keywords=["env", "empty"]
            ))
    return _make_sync_check(target_fn, check)




def database_not_forbidden_name(forbidden_provider: Callable[[Any], str]):
    """Decorator that ensures database name is not forbidden."""
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                env = (ctx.data or {}).get("env")
                if isinstance(env, dict):
                    forbidden = forbidden_provider(ctx.config)
                    bad = [k for k, v in env.items() if k.strip() == "DATABASE_URL" and v.strip() == forbidden]
                    if bad:
                        ctx.logger.warning("Database name cannot be '%s': %s", forbidden, bad)
                        ctx.add(ValidationIssue(
                            rule_id="database.forbidden_name",
                            message=f"Database name cannot be '{forbidden}': {sorted(bad)}",
                            keywords=["database", "forbidden"]
                        ))
            except Exception as e:
                ctx.logger.error("Error validating database name: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="database.forbidden_name",
                    message=f"Error validating database name: {e}",
                    keywords=["database", "forbidden"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


# ---- Custom decorator creation example ----
def service_name_length(min_length_provider: Callable[[Any], int]):
    """
    Example custom decorator factory for validating service name length.
    Usage: @service_name_length(lambda cfg: cfg.min_service_name_length)
    """
    def decorator(target_fn):
        def check(ctx: ValidationContext):
            try:
                min_length = min_length_provider(ctx.config)
                service_name = (ctx.data or {}).get("service", "")
                if not isinstance(service_name, str) or len(service_name) < min_length:
                    ctx.logger.warning("Service name must be at least %d characters", min_length)
                    ctx.add(ValidationIssue(
                        rule_id="service.name_length",
                        message=f"Service name must be at least {min_length} characters",
                        keywords=["service", "name", "length"]
                    ))
            except Exception as e:
                ctx.logger.error("Error validating service name length: %s", e, exc_info=True)
                ctx.add(ValidationIssue(
                    rule_id="service.name_length",
                    message=f"Error validating service name length: {e}",
                    keywords=["service", "name", "length"]
                ))
        return _make_sync_check(target_fn, check)
    return decorator


# Optional: logging wrappers for start/end; can be used on any validate function too.
def log_process(target_fn):
    """Decorator that logs start and end of process execution."""
    if inspect.iscoroutinefunction(target_fn):
        @functools.wraps(target_fn)
        async def wrapper(*args, **kwargs):
            logger.info("Starting process: %s", target_fn.__qualname__)
            try:
                res = await target_fn(*args, **kwargs)
                logger.info("Finished process: %s", target_fn.__qualname__)
                return res
            except Exception:
                logger.exception("Error in process: %s", target_fn.__qualname__)
                raise
        return wrapper
    else:
        @functools.wraps(target_fn)
        def wrapper(*args, **kwargs):
            logger.info("Starting process: %s", target_fn.__qualname__)
            try:
                res = target_fn(*args, **kwargs)
                logger.info("Finished process: %s", target_fn.__qualname__)
                return res
            except Exception:
                logger.exception("Error in process: %s", target_fn.__qualname__)
                raise
        return wrapper
