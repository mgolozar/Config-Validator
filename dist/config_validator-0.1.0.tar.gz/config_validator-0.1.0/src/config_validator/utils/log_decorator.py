"""Decorator for logging function execution."""
import functools
import inspect
import logging
from datetime import datetime


def log_process(logger_name: str = None):
    """
    Decorator that logs function start and end with timestamps.
    
    Works with both synchronous and asynchronous functions.
    Logs exceptions before re-raising them.
    
    Args:
        logger_name: Name of the logger to use. Defaults to function's module.
    
    Example:
        @log_process()
        def my_function():
            ...
    """
    def decorator(func):
        actual_logger = logging.getLogger(logger_name or func.__module__)
        
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = datetime.now()
                func_name = func.__name__
                
                actual_logger.info(f"Starting process: {func_name}")
                
                try:
                    result = await func(*args, **kwargs)
                    end_time = datetime.now()
                    duration = (end_time - start_time).total_seconds()
                    actual_logger.info(f"Finished process: {func_name} (took {duration:.2f}s)")
                    return result
                except Exception as e:
                    end_time = datetime.now()
                    duration = (end_time - start_time).total_seconds()
                    actual_logger.error(
                        f"Failed process: {func_name} after {duration:.2f}s: {type(e).__name__}: {e}"
                    )
                    raise
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = datetime.now()
                func_name = func.__name__
                
                actual_logger.info(f"Starting process: {func_name}")
                
                try:
                    result = func(*args, **kwargs)
                    end_time = datetime.now()
                    duration = (end_time - start_time).total_seconds()
                    actual_logger.info(f"Finished process: {func_name} (took {duration:.2f}s)")
                    return result
                except Exception as e:
                    end_time = datetime.now()
                    duration = (end_time - start_time).total_seconds()
                    actual_logger.error(
                        f"Failed process: {func_name} after {duration:.2f}s: {type(e).__name__}: {e}"
                    )
                    raise
            
            return sync_wrapper
    
    return decorator

